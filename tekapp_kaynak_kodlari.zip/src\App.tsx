import React, { useState, useEffect, useRef, useCallback } from "react";
import { Musteri, Parca, Bakim, StokKalemi } from "./types";
import {
  getMusteriler,
  saveMusteri,
  deleteMusteri,
  getParcalar,
  saveParca,
  deleteParca,
  getBakimlar,
  saveBakim,
  deleteBakim,
  updateBakimOdemeDurumu,
  importAllData,
  subscribeToChanges,
  unsubscribe,
  isSupabaseConfigured,
  getStok,
  updateStokMiktar,
  addStokKalemi,
  deleteStokKalemi,
} from "./db/supabase";
import { decreaseStockForBakim, increaseStock, StokYetersizError } from "./db/stok";
import type { RealtimeChannel } from "@supabase/supabase-js";

import MusteriListesi from "./components/MusteriListesi";
import MusteriDetay from "./components/MusteriDetay";
import ParcaKatalogu from "./components/ParcaKatalogu";
import YeniBakimKaydi from "./components/YeniBakimKaydi";
import StokYonetimi from "./components/StokYonetimi";
import Ayarlar from "./components/Ayarlar";

import { Users, Wrench, PlusCircle, Settings, Loader2, Package } from "lucide-react";

type TabType = "musteriler" | "katalog" | "yeni-bakim" | "stok" | "ayarlar";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>("musteriler");
  const [musteriler, setMusteriler] = useState<Musteri[]>([]);
  const [parcalar, setParcalar] = useState<Parca[]>([]);
  const [bakimlar, setBakimlar] = useState<Bakim[]>([]);
  const [stokKalemleri, setStokKalemleri] = useState<StokKalemi[]>([]);
  const [loading, setLoading] = useState(false); // Asla bekleme ekranı gösterme
  const [syncing, setSyncing] = useState(false);
  const [isOnline, setIsOnline] = useState(isSupabaseConfigured());
  const channelRef = useRef<RealtimeChannel | null>(null);

  const [selectedMusteriId, setSelectedMusteriId] = useState<number | null>(null);
  const [preSelectedMusteriId, setPreSelectedMusteriId] = useState<number | undefined>(undefined);

  // Cache anahtarları
  const CACHE_KEY_M = "tekapp_cache_musteriler";
  const CACHE_KEY_P = "tekapp_cache_parcalar";
  const CACHE_KEY_B = "tekapp_cache_bakimlar";

  // Cache'den oku
  const loadFromCache = useCallback(() => {
    try {
      const m = localStorage.getItem(CACHE_KEY_M);
      const p = localStorage.getItem(CACHE_KEY_P);
      const b = localStorage.getItem(CACHE_KEY_B);
      if (m) setMusteriler(JSON.parse(m));
      if (p) setParcalar(JSON.parse(p));
      if (b) setBakimlar(JSON.parse(b));
      if (m || p || b) setLoading(false); // Cache varsa anında aç
    } catch { /* ignore */ }
  }, []);

  // Cache'e yaz
  const saveToCache = (m: Musteri[], p: Parca[], b: Bakim[]) => {
    try {
      localStorage.setItem(CACHE_KEY_M, JSON.stringify(m));
      localStorage.setItem(CACHE_KEY_P, JSON.stringify(p));
      localStorage.setItem(CACHE_KEY_B, JSON.stringify(b));
    } catch { /* ignore */ }
  };

  const loadAllData = useCallback(async (showSyncing = false) => {
    try {
      if (showSyncing) setSyncing(true);
      const [m, p, b, s] = await Promise.all([getMusteriler(), getParcalar(), getBakimlar(), getStok()]);
      setMusteriler(m);
      setParcalar(p);
      setBakimlar(b);
      setStokKalemleri(s);
      saveToCache(m, p, b);
      setIsOnline(true);
    } catch (err) {
      console.error("Supabase bağlantı hatası:", err);
      setIsOnline(false);
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  }, []);

  useEffect(() => {
    // Anında cache'den aç
    loadFromCache();
    // Arka planda Supabase'den güncelle
    loadAllData(false);
    if (isSupabaseConfigured()) {
      channelRef.current = subscribeToChanges(() => loadAllData(true));
    }
    // Otomatik yedekleme: her 30 dakikada bir Supabase'den cache'e yaz
    const backupInterval = setInterval(() => {
      loadAllData(false);
    }, 30 * 60 * 1000); // 30 dakika
    return () => {
      if (channelRef.current) unsubscribe(channelRef.current);
      clearInterval(backupInterval);
    };
  }, [loadAllData, loadFromCache]);

  const handleAddOrEditMusteri = async (m: Omit<Musteri, "id"> & { id?: number }): Promise<boolean> => {
    const isNew = !m.id;
    if (isNew) {
      if (musteriler.some(e => e.ad.trim().toLowerCase() === m.ad.trim().toLowerCase())) {
        alert(`"${m.ad}" zaten kayıtlı!`);
        return false;
      }
    } else {
      if (musteriler.some(e => e.id !== m.id && e.ad.trim().toLowerCase() === m.ad.trim().toLowerCase())) {
        alert(`"${m.ad}" isimli başka bir müşteri var!`);
        return false;
      }
    }
    try {
      const updated = await saveMusteri(m);
      setMusteriler(updated);
      if (isNew) {
        const currentIds = new Set(musteriler.map(i => i.id));
        const newlyAdded = updated.find(i => !currentIds.has(i.id));
        if (newlyAdded) handleStartNewBakimFromCustomer(newlyAdded.id);
      }
      return true;
    } catch (err: any) {
      console.error(err);
      alert("Müşteri kaydedilirken hata oluştu: " + (err?.message || err));
      return false;
    }
  };

  const handleDeleteMusteri = async (id: number) => {
    try {
      const updated = await deleteMusteri(id);
      setMusteriler(updated);
      setBakimlar(bakimlar.filter(b => b.musteri_id !== id));
      if (selectedMusteriId === id) setSelectedMusteriId(null);
    } catch (err: any) {
      console.error(err);
      alert("Müşteri silinirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleAddOrEditParca = async (p: Omit<Parca, "id"> & { id?: number }) => {
    try {
      setParcalar(await saveParca(p));
    } catch (err: any) {
      console.error(err);
      alert("Parça kaydedilirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleDeleteParca = async (id: number) => {
    try {
      setParcalar(await deleteParca(id));
    } catch (err: any) {
      console.error(err);
      alert("Parça silinirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleSaveBakim = async (b: Omit<Bakim, "id">) => {
    try {
      const bakimItems = JSON.parse(b.parcalar || "[]");

      // 1. ÖNCE STOK VALIDATION — yetersizse bakımı KAYDETME
      if (Array.isArray(bakimItems) && bakimItems.length > 0) {
        try {
          await decreaseStockForBakim(bakimItems);
          // Düşüm başarılı → stokları yenile
          setStokKalemleri(await getStok());
        } catch (stokErr: any) {
          if (stokErr instanceof StokYetersizError) {
            // Stok yetersiz → işlemi ENGELLE
            alert(
              "❌ Bakım kaydedilemedi! Stok yetersiz:\n\n" +
              stokErr.hatalar.join("\n")
            );
            return; // Bakımı kaydetmeden çık
          }
          // Diğer stok hataları: uyar ama bakımı kaydet
          console.error("Stok düşümü hatası:", stokErr);
        }
      }

      // 2. STOK TAMAM → Bakım kaydını kaydet
      const yeniBakimlar = await saveBakim(b);
      setBakimlar(yeniBakimlar);
      setPreSelectedMusteriId(undefined);
    } catch (err: any) {
      console.error(err);
      alert("Bakım kaydı oluşturulurken hata oluştu: " + (err?.message || err));
    }
  };

  // Manuel stok artırımı (StokYonetimi'nde + butonundan)
  const handleIncreaseStock = async (id: number, quantity: number) => {
    try {
      setStokKalemleri(await increaseStock(id, quantity));
    } catch (err: any) {
      alert("Stok artırılırken hata: " + (err?.message || err));
    }
  };

  const handleUpdateStokMiktar = async (id: number, miktar: number) => {
    try {
      setStokKalemleri(await updateStokMiktar(id, miktar));
    } catch (err: any) {
      console.error(err);
      alert("Stok güncellenirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleAddStokKalemi = async (ad: string, miktar: number) => {
    try {
      setStokKalemleri(await addStokKalemi(ad, miktar));
    } catch (err: any) {
      console.error(err);
      alert("Kalem eklenirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleDeleteStokKalemi = async (id: number) => {
    try {
      setStokKalemleri(await deleteStokKalemi(id));
    } catch (err: any) {
      console.error(err);
      alert("Kalem silinirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleDeleteBakim = async (id: number) => {
    try {
      setBakimlar(await deleteBakim(id));
    } catch (err: any) {
      console.error(err);
      alert("Bakım kaydı silinirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleUpdateOdemeDurumu = async (id: number, odendi: number) => {
    try {
      setBakimlar(await updateBakimOdemeDurumu(id, odendi));
    } catch (err: any) {
      console.error(err);
      alert("Ödeme durumu güncellenirken hata oluştu: " + (err?.message || err));
    }
  };

  const handleImportBackup = async (data: { musteriler: Musteri[]; parcalar: Parca[]; bakimlar: Bakim[] }) => {
    try {
      await importAllData(data);
      await loadAllData();
    } catch (err: any) {
      console.error(err);
      alert("Veri yüklenirken hata oluştu: " + (err?.message || err));
    }
  };

  const getBackupPayload = () => ({ musteriler, parcalar, bakimlar });

  const getSortedParcalar = () => {
    const usageCount: { [key: number]: number } = {};
    parcalar.forEach(p => { usageCount[p.id] = 0; });
    bakimlar.forEach(b => {
      try {
        const list = JSON.parse(b.parcalar);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        if (Array.isArray(list)) list.forEach((item: any) => {
          usageCount[item.id] = (usageCount[item.id] || 0) + (item.adet || 1);
        });
      } catch { /* ignore */ }
    });
    return [...parcalar].sort((a, b) => (usageCount[b.id] || 0) - (usageCount[a.id] || 0));
  };

  const navigateToTab = (tab: TabType) => {
    setActiveTab(tab);
    if (tab !== "musteriler") setSelectedMusteriId(null);
    if (tab !== "yeni-bakim") setPreSelectedMusteriId(undefined);
  };

  const handleStartNewBakimFromCustomer = (custId: number) => {
    setPreSelectedMusteriId(custId);
    setActiveTab("yeni-bakim");
    setSelectedMusteriId(null);
  };

  const getScreenTitle = () => {
    if (activeTab === "musteriler") return selectedMusteriId ? "Müşteri Detay" : "Müşteriler";
    if (activeTab === "katalog") return "Parça Kataloğu";
    if (activeTab === "yeni-bakim") return "Yeni Bakım";
    if (activeTab === "stok") return "Stok Takibi";
    if (activeTab === "ayarlar") return "Ayarlar";
    return "TekApp";
  };

  const renderScreen = () => {
    if (loading) {
      return (
        <div className="flex flex-col items-center justify-center flex-1 gap-3 bg-slate-50">
          <Loader2 className="h-8 w-8 text-sky-500 animate-spin" />
          <span className="text-sm text-slate-500 font-medium">Yükleniyor...</span>
        </div>
      );
    }
    if (activeTab === "musteriler") {
      if (selectedMusteriId !== null) {
        return (
          <MusteriDetay
            musteriId={selectedMusteriId}
            musteriler={musteriler}
            bakimlar={bakimlar}
            onBack={() => setSelectedMusteriId(null)}
            onDeleteBakim={handleDeleteBakim}
            onNewBakimClick={handleStartNewBakimFromCustomer}
            onUpdateOdemeDurumu={handleUpdateOdemeDurumu}
          />
        );
      }
      return (
        <MusteriListesi
          musteriler={musteriler}
          onAddOrEdit={handleAddOrEditMusteri}
          onDelete={handleDeleteMusteri}
          onSelectMusteri={(id) => setSelectedMusteriId(id)}
        />
      );
    }
    if (activeTab === "katalog") {
      return (
        <ParcaKatalogu 
          parcalar={parcalar} 
          stokKalemleri={stokKalemleri}
          onAddOrEdit={handleAddOrEditParca} 
          onDelete={handleDeleteParca} 
        />
      );
    }
    if (activeTab === "yeni-bakim") {
      return (
        <YeniBakimKaydi
          initialMusteriId={preSelectedMusteriId}
          musteriler={musteriler}
          parcalar={getSortedParcalar()}
          onSave={handleSaveBakim}
          onNavigateToMusteriDetail={(id) => { setSelectedMusteriId(id); setActiveTab("musteriler"); }}
        />
      );
    }
    if (activeTab === "stok") {
      return (
        <StokYonetimi
          stokKalemleri={stokKalemleri}
          onUpdateMiktar={handleUpdateStokMiktar}
          onIncreaseStock={handleIncreaseStock}
          onAddKalem={handleAddStokKalemi}
          onDeleteKalem={handleDeleteStokKalemi}
          onRefresh={() => getStok().then(setStokKalemleri)}
        />
      );
    }
    if (activeTab === "ayarlar") {
      return <Ayarlar onImportData={handleImportBackup} getBackupData={getBackupPayload} />;
    }
    return null;
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-white overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* Mobil üst başlık */}
      <header className="bg-sky-600 text-white px-4 pt-safe flex items-center justify-between shrink-0"
        style={{ paddingTop: "env(safe-area-inset-top, 12px)", minHeight: "56px" }}>
        <div className="flex items-center gap-2 py-3">
          <div className="h-7 w-7 rounded-lg bg-white/20 flex items-center justify-center text-white font-bold text-xs">TA</div>
          <span className="font-bold text-base tracking-tight">{getScreenTitle()}</span>
        </div>
        <div className="flex items-center gap-1.5 py-3">
          {syncing && <Loader2 className="h-4 w-4 animate-spin text-white/70" />}
          <div className={`h-2 w-2 rounded-full ${isOnline ? "bg-emerald-300" : "bg-amber-300"}`} />
          <span className="text-[11px] text-white/80">{isOnline ? "Sync" : "Çevrimdışı"}</span>
        </div>
      </header>

      {/* İçerik alanı - tam ekran */}
      <div className="flex-1 overflow-hidden bg-slate-50 text-slate-800">
        {renderScreen()}
      </div>

      {/* Alt navigasyon çubuğu */}
      <nav className="bg-white border-t border-slate-200 flex justify-around items-center shrink-0"
        style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)", minHeight: "60px" }}>
        {[
          { tab: "musteriler" as TabType, icon: Users,      label: "Müşteriler" },
          { tab: "katalog"    as TabType, icon: Wrench,     label: "Katalog" },
          { tab: "yeni-bakim" as TabType, icon: PlusCircle, label: "Bakım Ekle" },
          { tab: "stok"       as TabType, icon: Package,    label: "Stok" },
          { tab: "ayarlar"    as TabType, icon: Settings,   label: "Ayarlar" },
        ].map(({ tab, icon: Icon, label }) => (
          <button
            key={tab}
            onClick={() => navigateToTab(tab)}
            className={`flex flex-col items-center justify-center flex-1 py-2 transition-colors ${
              activeTab === tab ? "text-sky-600" : "text-slate-400"
            }`}
          >
            <Icon className="h-5 w-5" />
            <span className="text-[10px] font-semibold mt-0.5">{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
