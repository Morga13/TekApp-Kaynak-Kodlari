import React, { useRef, useState } from "react";
import { Upload, Download } from "lucide-react";
import { Musteri, Parca, Bakim } from "../types";

interface AyarlarProps {
  onImportData: (data: { musteriler: Musteri[]; parcalar: Parca[]; bakimlar: Bakim[] }) => void;
  getBackupData: () => { musteriler: Musteri[]; parcalar: Parca[]; bakimlar: Bakim[] };
}

export default function Ayarlar({ onImportData, getBackupData }: AyarlarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);

  // Trigger Local Download of JSON Backup file
  const handleExport = () => {
    try {
      const backup = getBackupData();
      const payload = {
        versiyon: "1.0",
        tarih: new Date().toISOString(),
        ...backup
      };
      
      const jsonStr = JSON.stringify(payload, null, 2);
      const blob = new Blob([jsonStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement("a");
      link.href = url;
      link.download = `tekapp_yedek_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      alert("Yedek dosyası (.json) başarıyla indirildi. Bu dosyayı bilgisayarınızda veya Google Drive'da saklayabilirsiniz.");
    } catch (e) {
      console.error(e);
      alert("Yedek oluşturulurken bir hata oluştu.");
    }
  };

  // Read JSON backup file and upload
  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm("Geri yükleme işlemi, mevcut uygulamadaki tüm kayıtları silecektir ve yedekteki kayıtları geri yükleyecektir. Emin misiniz?")) {
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    setLoading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const backup = JSON.parse(text);

        if (!backup.musteriler || !backup.parcalar || !backup.bakimlar) {
          throw new Error("Geçersiz dosya yapısı. Yedek dosyası 'musteriler', 'parcalar' ve 'bakimlar' verilerini içermelidir.");
        }

        onImportData({
          musteriler: backup.musteriler,
          parcalar: backup.parcalar,
          bakimlar: backup.bakimlar
        });

        alert("Tüm veritabanı kayıtları yedek dosyasından başarıyla geri yüklendi!");
        window.location.reload(); // Refresh to reload state
      } catch (err: any) {
        alert("Geri yükleme başarısız: " + (err.message || "Geçersiz JSON formatı."));
      } finally {
        setLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-y-auto p-4 pb-24 space-y-5">
      {/* Veri Yönetimi */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider pl-1">Veri Yönetimi</h3>
        
        {/* Export Card */}
        <button
          onClick={handleExport}
          className="w-full bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs hover:shadow-md transition text-left focus:outline-none"
        >
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <Download className="h-5 w-5" />
            </div>
            <div>
              <span className="font-bold text-slate-800 text-sm block">Verileri Yedekle (JSON İndir)</span>
              <span className="text-xs text-slate-400 mt-1 block leading-relaxed">
                Tüm müşteri, parça ve bakım kayıtlarını tek bir JSON yedek dosyası olarak kaydet.
              </span>
            </div>
          </div>
        </button>

        {/* Import Card */}
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={loading}
          className="w-full bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs hover:shadow-md transition text-left focus:outline-none"
        >
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
              <Upload className="h-5 w-5" />
            </div>
            <div>
              <span className="font-bold text-slate-800 text-sm block">Yedekten Geri Yükle</span>
              <span className="text-xs text-slate-400 mt-1 block leading-relaxed">
                Daha önce indirdiğin bir yedek (.json) dosyasını yükleyerek tüm verileri geri yükle.
              </span>
            </div>
          </div>
        </button>
        <input
          type="file"
          accept=".json"
          ref={fileInputRef}
          onChange={handleImport}
          className="hidden"
        />
      </div>
    </div>
  );
}
